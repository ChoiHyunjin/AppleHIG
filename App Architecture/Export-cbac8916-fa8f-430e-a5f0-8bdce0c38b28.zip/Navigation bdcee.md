# Navigation

사람들은 자신의 기대에 만족하지 않기 전까진, 네비게이션을 눈치채지 못한다. 주의를 환기시키지 않고 앱의 구조와 목적을 지원하도록 네비게이션을 구현해야한다. 네비게이션은 자연스럽고 친숙하며, 인터페이스를 지배하거나 컨텐츠로의 집중을 깨지 않아야한다. iOS에는 세 가지 스타일의 네비게이션이 있다.

## Hierarchical

![스크린샷 2022-03-22 오후 12.26.18.png](Navigation%20bdcee/%E1%84%89%E1%85%B3%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%AB%E1%84%89%E1%85%A3%E1%86%BA_2022-03-22_%E1%84%8B%E1%85%A9%E1%84%92%E1%85%AE_12.26.18.png)

목적지 도달까지, 한번에 한 화면을 이동한다. 다른 목적지를 위해서는, 이전 과정들을 다시 밟거나 처음부터 시작하여 다른 길로 가야한다.

설정(Settings), 메일(Mail) 앱이 이 네비게이션 스타일이다.

## Flat

![스크린샷 2022-03-22 오후 12.28.37.png](Navigation%20bdcee/%E1%84%89%E1%85%B3%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%AB%E1%84%89%E1%85%A3%E1%86%BA_2022-03-22_%E1%84%8B%E1%85%A9%E1%84%92%E1%85%AE_12.28.37.png)

컨텐츠 카테고리간 전환 방법. Music, App Store가 이 방식이다.

## ****Content-Driven or Experience-Driven****

![스크린샷 2022-03-22 오후 12.34.28.png](Navigation%20bdcee/%E1%84%89%E1%85%B3%E1%84%8F%E1%85%B3%E1%84%85%E1%85%B5%E1%86%AB%E1%84%89%E1%85%A3%E1%86%BA_2022-03-22_%E1%84%8B%E1%85%A9%E1%84%92%E1%85%AE_12.34.28.png)

내용에 따라 자유롭게 움직이거나, 내용이 navigation을 정한다. 게임, 책, 다른 immersive 앱들이 이 스타일을 채택한다.

일부 앱들은 여러 네비게이션 스타일을 조합하여 사용한다. 예를 들어, flat 스타일의 한 앱은 각 카테고리는 hierarchcal 스타일로 구현하기도 했다.

## 분명한 Path

사용자는 자기가 앱의 어디에 있는지, 그리고 목적지에 어떻게 가야하는지 알아야한다. 네비게이션 스타일에 상관 없이, 내용을 통한 path가 논리적이고 예측 가능하며 따라하기 쉬워야한다. 일반적으로 각 화면마다 하나의 path를 줘라. 한 화면에서 여러 문맥을 보여줄 필요가 있다면, action sheet / alert / popover / modal view 등을 이용하라.

## 내용을 빠르고 쉽게 얻을 수 있는 정보

최소한의 탭, 스와이프, 화면만 필요하도록 정보 구조를 구성해라.

---

원본

[Navigation - App Architecture - iOS - Human Interface Guidelines - Apple Developer](https://developer.apple.com/design/human-interface-guidelines/ios/app-architecture/navigation/)